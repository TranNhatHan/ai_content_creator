# Eastern philosophy

## Buddhism

BEFORE

c.1500 BCE Vedism reaches the Indian subcontinent.

c.10th–5th centuries BCE Brahmanism replaces Vedic beliefs.

AFTER

3rd century BCE Buddhism spreads from the Ganges valley westward across India.

1st century BCE The teachings of Siddhartha Gautama are written down for the first time.

1st century CE Buddhism starts to spread to China and Southeast Asia. Different schools of Buddhism begin to evolve in different areas.

Siddhartha Gautama, later known as the Buddha, “the enlightened one”, lived in India during a period when religious and mythological accounts of the world were being questioned. In Greece, thinkers such as Pythagoras were examining the cosmos using reason, and in China, Laozi and Confucius were detaching ethics from religious dogma. Brahmanism, a religion that had evolved from Vedism—an ancient belief based on the sacred Veda texts—was the dominant faith in the Indian subcontinent in the 6th century BCE, and Siddhartha Gautama was the first to challenge its teachings with philosophical reasoning.

Gautama, although revered by Buddhists for his wisdom, was neither a messiah nor a prophet, and he did not act as a medium between God and Man. His ideas were arrived at through reasoning, not divine revelation, and it is this that marks Buddhism out as a philosophy as much as (perhaps even more than) a religion. His quest was philosophical—to discover truths—and he maintained that these truths are available to all of us through the power of reason. Like most Eastern philosophers, he was not interested in the unanswerable questions of metaphysics that preoccupied the Greeks. Dealing with entities beyond our experience, this kind of enquiry was senseless speculation. Instead, he concerned himself with the question of the goal of life, which in turn involved examining the concepts of happiness, virtue, and the “good” life.

The middle way

In his early life, Gautama enjoyed luxury and, we are told, all the sensual pleasures. However, he realized that these were not enough on their own to bring him true happiness. He was acutely aware of the suffering in the world, and saw that it was largely due to sickness, old age, and death, and the fact that people lack what they need. He also recognized that the sensual pleasure we indulge in to relieve suffering is rarely satisfying, and that when it is, the effects are transitory. He found the experience of extreme asceticism (austerity and abstinence) equally dissatisfying, bringing him no nearer to an understanding of how to achieve happiness.

Gautama came to the conclusion that there must be a “middle way” between self-indulgence and self-mortification. This middle way, he believed, should lead to true happiness, or “enlightenment”, and to find it he applied reason to his own experiences.

Suffering, he realized, is universal. It is an integral part of existence, and the root cause of our suffering is the frustration of our desires and expectations. These desires he calls “attachments”, and they include not only our sensual desires and worldly ambitions, but our most basic instinct for self-preservation. Satisfying these attachments, he argues, may bring short-term gratification, but not happiness in the sense of contentment and peace of mind.

The Buddha cut off his hair as part of his renunciation of the material world. According to Buddhist teaching, the temptations of the world are the source of all suffering, and must be resisted.

The “not-self”

The next step in Gautama’s reasoning is that the elimination of attachments will prevent any disappointment, and so avoid suffering. To achieve this, he suggests a root cause of our attachments—our selfishness, and by selfishness he means more than just our tendency to seek gratification. For Gautama, selfishness is self-centeredness and self-attachment—the domain of what today we would call the “ego.” So, to free ourselves from attachments that cause us pain, it is not enough merely to renounce the things we desire—we must overcome our attachment to that which desires—the “self.”

But how can this be done? Desire, ambition, and expectation are part of our nature, and for most of us constitute our very reasons for living. The answer, for Gautama, is that the ego’s world is illusory—as he shows, again, by a process of reasoning. He argues that nothing in the universe is self-caused, for everything is the result of some previous action, and each of us is only a transitory part of this eternal process—ultimately impermanent and without substance. So, in reality, there is no “self” that is not part of the greater whole—or the “not-self”—and suffering results from our failure to recognize this. This does not mean that we should deny our existence or personal identity, rather that we should understand them for what they are—transient and insubstantial. Grasping the concept of being a constituent part of an eternal “not-self”, rather than clinging to the notion of being a unique “self”, is the key to losing that attachment, and finding a release from suffering.

"Believe nothing, no matter where you read it, or who said it, unless it agrees with your own reason."

Siddhartha Gautama

The Eightfold Path

Gautama’s reasoning from the causes of suffering to the way to achieve happiness is codified in Buddhist teachings in the Four Noble Truths: that suffering is universal; that desire is the cause of suffering; that suffering can be avoided by eliminating desire; that following the Eightfold Path will eliminate desire. This last Truth refers to what amounts to a practical guide to the “middle way” that Gautama laid out for his followers to achieve enlightenment. The Eightfold Path (right action, right intention, right livelihood, right effort, right concentration, right speech, right understanding, and right mindfulness) is in effect a code of ethics—a prescription for a good life and the happiness that Gautama first set out to find.

"Peace comes from within. Do not seek it without."

Siddhartha Gautama

Nirvana

Gautama sees the ultimate goal of life on Earth to be the ending of the cycle of suffering (birth, death, and rebirth) into which we are born. By following the Eightfold Path, a man can overcome his ego and live a life free from suffering, and through his enlightenment he can avoid the pain of rebirth into another life of suffering. He has realized his place in the “not-self”, and become at one with the eternal. He has attained the state of Nirvana—which is variously translated as “non-attachment”, “not-being”, or literally “blowing out” (as of a candle).

In the Brahmanism of Gautama’s time, and the Hindu religion that followed, Nirvana was seen as becoming one with god, but Gautama carefully avoids any mention of a deity or of an ultimate purpose to life. He merely describes Nirvana as “unborn, unoriginated, uncreated, and unformed”, and transcending any sensory experience. It is an eternal and unchanging state of not-being, and so the ultimate freedom from the suffering of existence.

Gautama spent many years after his enlightenment traveling around India, preaching and teaching. During his lifetime, he gained a considerable following, and Buddhism became established as a major religion as well as a philosophy. His teachings were passed down orally from generation to generation by his followers, until the 1st century CE, when they were written down for the first time. Various schools began to appear as Buddhism spread across India, and later spread eastward into China and Southeast Asia, where it rivalled Confucianism and Daoism in its popularity.

Gautama’s teachings spread as far as the Greek empire by the 3rd century BCE, but had little influence on Western philosophy. However, there were similarities between Gautama’s approach to philosophy and that of the Greeks, not least Gautama’s emphasis on reasoning as a means of finding happiness, and his disciples’ use of philosophical dialogues to elucidate his teachings. His thoughts also find echoes in the ideas of later Western philosophers, such as in Hume’s concept of the self and Schopenhauer’s view of the human condition. But it was not until the 20th century that Buddhism was to have any direct influence on Western thinking. Since then, more and more Westerners have turned to it for guidance on how to live.

"The mind is everything. What you think, you become."

Siddhartha Gautama

The dharma wheel, one of the oldest Buddhist symbols, represents the Eightfold Path to Nirvana. In Buddhism, the word “dharma” refers to the teachings of the Buddha.

SIDDHARTHA GAUTAMA

Almost all we know of Siddhartha Gautama’s life comes from biographies written by his followers centuries after his death, and which differ widely in many details. What is certain is that he was born in Lumbini, modern-day Nepal, some time around 560 BCE. His father was an official, possibly the leader of a clan, and Siddhartha led a privileged life of luxury and high status.

Dissatisfied with this, Siddhartha left his wife and son to find a spiritual path, and discovered the “middle way” between sensual indulgence and asceticism. He experienced enlightenment while thinking in the shade of a bodhi tree, and devoted the rest of his life to travelling throughout India, preaching. After his death, his teachings were passed down orally for some 400 years before being written down in the Tipitaka (Three Baskets).

Key works

1st century CE Tipitaka (recounted by his followers), comprising: Vinaya-pitaka, Sutta-pitaka, Abhidhamma-pitaka

