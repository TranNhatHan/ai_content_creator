# Philosophy of religion

## Atheism

BEFORE

c.600 BCE Thales is the first Western philosopher to deny that the universe owes its existence to a god.

c.500 BCE The Indian school of atheistic philosophy known as Carvaka is established.

c.400 BCE The ancient Greek philosopher Diagoras of Melos puts forward arguments in defense of atheism.

AFTER

Mid-19th century Karl Marx uses Feuerbach’s reasoning in his philosophy of political revolution.

Late 19th century The psychoanalyst Sigmund Freud argues that religion is a projection of human wishes.

The 19th-century German philosopher Ludwig Feuerbach is best known for his book The Essence of Christianity (1841), which inspired revolutionary thinkers such as Karl Marx and Friedrich Engels. The book incorporates much of the philosophical thinking of Georg Hegel, but where Hegel saw an Absolute Spirit as the guiding force in nature, Feuerbach sees no reason to look beyond our experience to explain existence. For Feuerbach, humans are not an externalized form of an Absolute Spirit, but the opposite: we have created the idea of a great spirit, a god, from our own longings and desires.

Imagining God

Feuerbach suggests that in our yearning for all that is best in humankind—love, compassion, kindness, and so on—we have imagined a being that incorporates all of these qualities in the highest possible degree, and then called it “God.” Theology (the study of God) is therefore nothing more than anthropology (the study of humanity). Not only have we deceived ourselves into thinking that a divine being exists, we have also forgotten or forsaken what we are ourselves. We have lost sight of the fact that these virtues actually exist in humans, not gods. For this reason we should focus less on heavenly righteousness and more on human justice—it is people in this life, on this Earth, that deserve our attention.

The Israelites of the Bible, in their need for certainty and reassurance, created a false god—the golden calf—to worship. Feuerbach argues that all gods are created in the same way.

