# Metaphysics

## Monism



## Pythagoreanism



## Monism



## Monism



## Atomism



## Epistemology



## Epistemology



## Epistemology



## Epistemology



## Idealism



## Transcendental idealism



## Idealism



## Idealism



## Existentialism



