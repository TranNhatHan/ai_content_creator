# Aesthetics

## Analytic philosophy



