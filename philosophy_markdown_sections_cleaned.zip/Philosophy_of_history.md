# Philosophy of history

## Naturalism



## Hermeneutics



