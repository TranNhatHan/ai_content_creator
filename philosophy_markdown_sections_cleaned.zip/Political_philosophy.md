# Political philosophy

## Social contract theory



## Classical economics



## Conservatism



## Feminism



## Utilitarianism



## Communism



## Non-conformism



## Frankfurt School



## Social contract theory



## Existentialism



## Social theory



## Feminism



## Post-colonialism



## Feminism



## Marxism



