# Eastern philosophy

## Buddhism



