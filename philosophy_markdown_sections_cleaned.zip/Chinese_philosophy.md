# Chinese philosophy

## Daoism



## Confucianism



## Mohism



